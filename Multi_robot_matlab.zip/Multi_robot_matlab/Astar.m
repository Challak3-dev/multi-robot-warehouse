function path = Astar(M, start, goal)

    % Convert to node-based
    M = ~M; % now 1=free, 0=wall
    sz = size(M);
    
    % open and closed lists
    open = start;
    cost = containers.Map();
    parent = containers.Map();
    
    key = @(x) sprintf('%d_%d', x(1), x(2));
    
    cost(key(start)) = 0;
    
    while ~isempty(open)
        % find node with lowest cost + heuristic
        fvals = [];
        for i = 1:size(open,1)
            node = open(i,:);
            g = cost(key(node));
            h = norm(node - goal);
            fvals(i) = g + h;
        end
        
        [~,idx] = min(fvals);
        current = open(idx,:);
        open(idx,:) = [];
        
        if isequal(current, goal)
            break;
        end
        
        % neighbors (4-connected)
        nb = [ 0 1; 1 0; 0 -1; -1 0 ];
        
        for i = 1:4
            next = current + nb(i,:);
            if next(1)<1 || next(1)>sz(1) || next(2)<1 || next(2)>sz(2)
                continue;
            end
            if M(next(1), next(2)) == 0
                continue;
            end
            
            g_new = cost(key(current)) + 1;
            k = key(next);
            
            if ~isKey(cost,k) || g_new < cost(k)
                cost(k) = g_new;
                parent(k) = current;
                open = [open; next];
            end
        end
    end
    
    % reconstruct path
    path = goal;
    cur = goal;
    while ~isequal(cur, start)
        cur = parent(key(cur));
        path = [cur; path];
    end
end
