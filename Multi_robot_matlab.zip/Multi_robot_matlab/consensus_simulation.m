%% ===============================================================
%   MULTI-ROBOT CONSENSUS SIMULATION
%   Section IV: Validation (MATLAB)
%   Author: Krishna Vamshi
%   Date: 2025
% ===============================================================

clear; clc; close all;

%% ---------------------- PARAMETERS ----------------------------
N = 6;              % number of robots
T = 300;            % total time steps
dt = 0.05;          % time step

% Random initial positions (2D)
pos = 10*rand(N,2);

% Ring communication graph (each robot talks to neighbors)
A = diag(ones(N-1,1),1) + diag(ones(N-1,1),-1);
A(1,N) = 1;
A(N,1) = 1;

% Degree matrix
D = diag(sum(A,2));

% Laplacian
L = D - A;

%% ---------------------- SIMULATION ----------------------------
positions_over_time = zeros(N,2,T);
positions_over_time(:,:,1) = pos;

figure(1); hold on;
colors = lines(N);

for t = 1:T
    % Consensus dynamics: x_dot = -Lx
    dx = -L * pos;

    % Update
    pos = pos + dt * dx;

    positions_over_time(:,:,t) = pos;

    % Plotting
    clf;
    for i = 1:N
        plot(pos(i,1), pos(i,2), 'o', 'MarkerSize', 10, ...
             'MarkerFaceColor', colors(i,:), 'MarkerEdgeColor', 'k');
        hold on;
    end
    title("Consensus Dynamics — Robots Converging to Agreement");
    xlabel("X"); ylabel("Y");
    xlim([0 10]); ylim([0 10]);
    grid on; drawnow;
end
