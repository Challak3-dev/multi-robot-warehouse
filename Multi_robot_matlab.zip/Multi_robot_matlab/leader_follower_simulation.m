%% ===============================================================
%   MULTI-ROBOT LEADER–FOLLOWER FORMATION SIMULATION
%   Section IV: Validation (MATLAB)
%   Author: Krishna Vamshi
%   Date: 2025
% ===============================================================

clear; clc; close all;

%% ---------------------- PARAMETERS ----------------------------
N = 6;                  % total robots
leader = 1;             % leader index
dt = 0.05;              % time step
T = 400;                % steps

% Leader goal position
goal = [20, 20];

% Initial positions
pos = 5 * rand(N, 2);

% Formation offsets relative to leader
% Robot 1 is leader → offset [0 0]
formation = [ 0   0;
              2   0;
             -2   0;
              1   1.5;
             -1   1.5;
              0   3];

% Control gains
k_leader = 0.6;
k_follow = 1.2;

%% ---------------------- SIMULATION ----------------------------
positions_over_time = zeros(N, 2, T);

figure(1);
colors = lines(N);

for t = 1:T
    
    dx = zeros(N,2);

    % ----------------- Leader Control -----------------
    leader_error = pos(leader,:) - goal;
    dx(leader,:) = -k_leader * leader_error;

    % ----------------- Followers Control ---------------
    for i = 2:N
        desired_pos = pos(leader,:) + formation(i,:);
        error_i = pos(i,:) - desired_pos;
        dx(i,:) = -k_follow * error_i;
    end
    
    % Update robot states
    pos = pos + dt * dx;

    positions_over_time(:,:,t) = pos;

    % ----------------- Plotting ------------------------
    clf; hold on;

    % Leader
    plot(pos(leader,1), pos(leader,2), 'ro', 'MarkerSize',15, ...
         'MarkerFaceColor','r');
    text(pos(leader,1)+0.3, pos(leader,2)+0.3, 'Leader', 'Color','r');

    % Followers
    for i = 2:N
        plot(pos(i,1), pos(i,2), 'o', 'MarkerSize',12, ...
            'MarkerFaceColor', colors(i,:), 'MarkerEdgeColor','k');
        text(pos(i,1)+0.2, pos(i,2)+0.2, sprintf('R%d', i));
    end

    % Draw formation links
    for i = 2:N
        desired = pos(leader,:) + formation(i,:);
        plot([pos(i,1), desired(1)], [pos(i,2), desired(2)], '--k');
    end

    % Plot formatting
    plot(goal(1), goal(2), 'gx', 'MarkerSize', 14, 'LineWidth', 2);
    title("Leader–Follower Formation Control");
    xlabel("X (m)"); ylabel("Y (m)");
    axis equal; grid on;
    xlim([0 25]); ylim([0 25]);
    drawnow;

    %% ---------------------- PLOT FORMATION ERROR ------------------------

errors = zeros(N-1, T);

for t = 1:T
    for i = 2:N
        desired = positions_over_time(leader,:,t) + formation(i,:);
        errors(i-1,t) = norm(positions_over_time(i,:,t) - desired);
    end
end

figure(2); hold on;
for i = 1:N-1
    plot(errors(i,:));
end
title("Formation Error Over Time");
xlabel("Time Step");
ylabel("Error (m)");
grid on;

end
